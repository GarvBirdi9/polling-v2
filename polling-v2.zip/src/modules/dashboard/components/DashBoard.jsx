import React from "react";
import Header from "../../../shared/components/Header";
import Landing from "../../landing/components/Landing";

const DashBoard = () => {
  return (
    <div>
      <Header />
      <Landing />
    </div>
  );
};

export default DashBoard;
